# 📊 Veckovis Aktiescan
**Datum:** 2026-05-12 15:04  
**Scannade:** 120 aktier
**Vikter:** Value 22% · Quality 18% · Momentum 18% · Growth 13% · Risk 9% · Sentiment 10%
**Signaler:** 69 upptrend · 19 HÖG konfidens · 3 STARK entry

---


## 🐂 Marknadsregim: **TJUR**

_Konfidens: 67%_  
_Per: 2026-05-12 14:55_

| Indikator | Värde |
|-----------|-------|
| SPY vs MA200 | +10.2% |
| VIX | 18.7 |
| SPY 3-mån | +7.1% |

**Anmärkningar:**
- SPY +10.2% över MA200, VIX 18.7

✅ **Tjurmarknad:** Standardvikter används. Momentum-faktorn har lätt förhöjd vikt.
## 🏆 Topp 50 aktier (Max 5 per sektor)

| Rank | Ticker | Bolag | Score | Entry | Konf | Trend | RS | Insider | EPS | Δ |
|------|--------|-------|-------|-------|------|-------|----|---------|-----|---|
| 1 | `INVE-A.ST` | Investor AB (publ) | **84** | 🔵 OK | HÖG | ✅ | ⚪ NORMAL | ⚪ | ⚪ | 📈 +8p |
| 3 | `INDU-C.ST` | AB Industrivärden (pub | **82** | 🟢 STARK | HÖG | ✅ | ⚪ NORMAL | ⚪ | ⚪ | 📈 +8p |
| 4 | `INDU-A.ST` | AB Industrivärden (pub | **81** | 🔵 OK | HÖG | ✅ | ⚪ NORMAL | ⚪ | ⚪ | 📈 +8p |
| 11 | `INVE-B.ST` | Investor AB (publ) | **73** | 🔵 OK | HÖG | ✅ | ⚪ NORMAL | ⚪ | ⚪ |  |
| 2 | `ANTO.L` | Antofagasta plc | **83** | 🔵 OK | HÖG | ✅ | 🟢 STARK | ⚪ | ⚪ | 📈 +13p |
| 8 | `PRU.L` | Prudential plc | **74** | 🔵 OK | HÖG | ✅ | ⚪ NORMAL | ⚪ | ⚪ | 📈 +8p |
| 5 | `INSTAL.ST` | Instalco AB (publ) | **80** | 🔵 OK | MEDEL | ✅ | 🟢 STARK | ⚪ | 🔴 | 📈 +13p |
| 28 | `BP.L` | BP p.l.c. | **66** | 🔵 OK | MEDEL | ✅ | 🟢 STARK | 🔴 | 🟢 | 📤 LÄMNAT TOPP20 · ⬇ -19 |
| 18 | `RIO.L` | Rio Tinto Group | **70** | 🟡 VÄNTA | HÖG | ✅ | 🟢 STARK | 🔴 | ⚪ |  |
| 15 | `GRNG.ST` | Gränges AB (publ) | **72** | 🟡 VÄNTA | HÖG | ✅ | 🟢 STARK | ⚪ | ⚪ |  |
| 20 | `AAL.L` | Anglo American plc | **69** | 🔵 OK | LÅG | ✅ | 🟢 STARK | 🔴 | ⚪ |  |
| 19 | `CAST.ST` | Castellum AB (publ) | **70** | 🔵 OK | MEDEL | ✅ | 🟢 STARK | ⚪ | ⚪ |  |
| 7 | `DIOS.ST` | Diös Fastigheter AB (p | **78** | 🟢 STARK | HÖG | ✅ | ⚪ NORMAL | ⚪ | ⚪ | 📈 +13p |
| 22 | `GLEN.L` | Glencore plc | **68** | 🟡 VÄNTA | MEDEL | ✅ | 🟢 STARK | ⚪ | ⚪ | 📤 LÄMNAT TOPP20 |
| 33 | `TEL2-B.ST` | Tele2 AB (publ) | **65** | 🔵 OK | HÖG | ✅ | ⚪ NORMAL | ⚪ | 🔴 |  |
| 46 | `SHEL.L` | Shell plc | **61** | 🟡 VÄNTA | HÖG | ✅ | 🟢 STARK | 🔴 | 🟢 | ⬇ -22 |
| 12 | `ENEA.ST` | Enea AB (publ) | **73** | 🟡 VÄNTA | LÅG | ✅ | ⚪ NORMAL | ⚪ | 🟢 | 📈 +10p |
| 9 | `CLAS-B.ST` | Clas Ohlson AB (publ) | **74** | 🟢 STARK | MEDEL | ✅ | 🟢 STARK | ⚪ | 🟢 | 🆕 NY I TOPP20 · 📈 +13p |
| 6 | `NCAB.ST` | NCAB Group AB (publ) | **79** | 🟡 VÄNTA | MEDEL | ✅ | 🟢 STARK | ⚪ | ⚪ | 🆕 NY I TOPP20 · 📈 +18p · ⬆ +19 |
| 41 | `TSCO.L` | Tesco PLC | **64** | 🟡 VÄNTA | HÖG | ✅ | 🟢 STARK | 🔴 | ⚪ |  |
| 97 | `GSK.L` | GSK plc | **42** | 🔴 EJ AKTUELL | MEDEL | ✅ | 🔴 SVAG | 🟢 | 🟢 | 📤 LÄMNAT TOPP20 · 📉 -20p · ⬇ -78 |
| 16 | `EMIL-B.ST` | Fastighetsbolaget Emil | **71** | 🔵 OK | LÅG | ✅ | ⚪ NORMAL | ⚪ | 🔴 | 🆕 NY I TOPP20 · 📈 +13p · ⬆ +25 |
| 39 | `BT-A.L` | BT Group plc | **64** | 🟡 VÄNTA | MEDEL | ✅ | 🟢 STARK | ⚪ | ⚪ |  |
| 40 | `PLAZ-B.ST` | Platzer Fastigheter Ho | **64** | 🟡 VÄNTA | MEDEL | ✅ | 🔴 SVAG | ⚪ | ⚪ |  |
| 13 | `MILDEF.ST` | MilDef Group AB (publ) | **73** | 🔵 OK | LÅG | ✅ | 🟢 STARK | ⚪ | 🔴 | 🆕 NY I TOPP20 · 📈 +13p · ⬆ +19 |
| 10 | `PNDX-B.ST` | Pandox AB (publ) | **73** | 🔴 EJ AKTUELL | MEDEL | ⚠️ | 🔴 SVAG | ⚪ | ⚪ | 🆕 NY I TOPP20 · 📈 +13p · ⬆ +19 |
| 29 | `BATS.L` | British American Tobac | **66** | 🔵 OK | HÖG | ✅ | ⚪ NORMAL | 🟢 | ⚪ |  |
| 102 | `AZN.L` | AstraZeneca PLC | **41** | 🔴 EJ AKTUELL | MEDEL | ✅ | 🟢 STARK | ⚪ | 🟢 | 📉 -20p · ⬇ -79 |
| 14 | `CTM.ST` | Catena Media plc | **72** | 🔵 OK | LÅG | ✅ | 🟢 STARK | ⚪ | ⚪ | 🆕 NY I TOPP20 · 📈 +13p · ⬆ +22 |
| 31 | `EXPN.L` | Experian plc | **65** | 🔴 EJ AKTUELL | MEDEL | ⚠️ | 🟢 STARK | 🟢 | ⚪ |  |
| 38 | `TELIA.ST` | Telia Company AB (publ | **64** | 🟡 VÄNTA | LÅG | ✅ | 🟢 STARK | ⚪ | 🟢 |  |
| 56 | `BILI-A.ST` | Bilia AB (publ) | **55** | 🔴 EJ AKTUELL | MEDEL | ✅ | ⚪ NORMAL | ⚪ | 🔴 | ⬇ -16 |
| 42 | `ABB.ST` | ABB Ltd | **63** | 🟡 VÄNTA | HÖG | ✅ | 🟢 STARK | ⚪ | 🟢 |  |
| 17 | `VOD.L` | Vodafone Group Public  | **71** | 🔵 OK | MEDEL | ✅ | 🟢 STARK | 🟢 | ⚪ | 🆕 NY I TOPP20 · 📈 +13p · ⬆ +25 |
| 47 | `AQ.ST` | AQ Group AB (publ) | **61** | 🟡 VÄNTA | MEDEL | ✅ | 🟢 STARK | ⚪ | 🔴 |  |
| 23 | `SKIS-B.ST` | SkiStar AB (publ) | **68** | 🔴 EJ AKTUELL | LÅG | ⚠️ | 🔴 SVAG | ⚪ | 🔴 | 📈 +13p · ⬆ +23 |
| 107 | `XVIVO.ST` | Xvivo Perfusion AB (pu | **34** | 🔴 EJ AKTUELL | LÅG | ✅ | 🟢 STARK | ⚪ | 🔴 | 📉 -20p · ⬇ -59 |
| 53 | `DGE.L` | Diageo plc | **57** | 🔴 EJ AKTUELL | MEDEL | ⚠️ | 🔴 SVAG | 🔴 | ⚪ |  |
| 54 | `IMB.L` | Imperial Brands PLC | **56** | 🔴 EJ AKTUELL | MEDEL | ⚠️ | 🔴 SVAG | 🔴 | ⚪ |  |
| 43 | `ERIC-B.ST` | Telefonaktiebolaget LM | **62** | 🟡 VÄNTA | LÅG | ✅ | 🔴 SVAG | ⚪ | 🟢 | 📈 +10p |
| 115 | `ARJO-B.ST` | Arjo AB (publ) | **30** | 🔴 EJ AKTUELL | LÅG | ⚠️ | ⚪ NORMAL | ⚪ | 🔴 | 📉 -20p · ⬇ -53 |
| 36 | `MIPS.ST` | Mips AB (publ) | **65** | 🔴 EJ AKTUELL | LÅG | ⚠️ | ⚪ NORMAL | ⚪ | ⚪ | 📈 +13p · ⬆ +22 |
| 55 | `EVO.ST` | Evolution AB (publ) | **55** | 🔴 EJ AKTUELL | MEDEL | ⚠️ | 🟢 STARK | ⚪ | ⚪ |  |
| 114 | `GETI-B.ST` | Getinge AB (publ) | **31** | 🔴 EJ AKTUELL | MEDEL | ⚠️ | ⚪ NORMAL | ⚪ | 🟢 | 📉 -20p · ⬇ -53 |
| 32 | `HEXA-B.ST` | Hexagon AB (publ) | **65** | 🔴 EJ AKTUELL | HÖG | ⚠️ | 🔴 SVAG | ⚪ | 🔴 | 📈 +18p · ⬆ +45 |
| 70 | `AXFO.ST` | Axfood AB (publ) | **52** | 🔴 EJ AKTUELL | LÅG | ⚠️ | 🔴 SVAG | ⚪ | ⚪ |  |
| 51 | `ANOD-B.ST` | Addnode Group AB (publ | **58** | 🔴 EJ AKTUELL | LÅG | ⚠️ | 🔴 SVAG | ⚪ | 🟢 | 📈 +10p · ⬆ +19 |
| 116 | `MINEST.ST` | Minesto AB (publ) | **28** | 🔴 EJ AKTUELL | LÅG | ⚠️ | 🟢 STARK | ⚪ | ⚪ | 📉 -8p |

## 🏥 Piotroski F-Score (finansiell hälsa)

_9-punkts finansiell hälsokoll. 7-9 = STARK, 4-6 = NEUTRAL, 0-3 = SVAG_

| Rank | Ticker | Bolag | F-Score | Status | Score |
|------|--------|-------|---------|--------|-------|
| 1 | `INVE-A.ST` | Investor AB (publ) | **7/9** | 🟢 STARK | 84 |
| 3 | `INDU-C.ST` | AB Industrivärden (pub | **8/9** | 🟢 STARK | 82 |
| 4 | `INDU-A.ST` | AB Industrivärden (pub | **8/9** | 🟢 STARK | 81 |
| 11 | `INVE-B.ST` | Investor AB (publ) | **6/9** | ⚪ NEUTRAL | 73 |
| 2 | `ANTO.L` | Antofagasta plc | **8/9** | 🟢 STARK | 83 |
| 8 | `PRU.L` | Prudential plc | **8/9** | 🟢 STARK | 74 |
| 5 | `INSTAL.ST` | Instalco AB (publ) | **7/9** | 🟢 STARK | 80 |
| 28 | `BP.L` | BP p.l.c. | **6/9** | ⚪ NEUTRAL | 66 |
| 18 | `RIO.L` | Rio Tinto Group | **5/9** | ⚪ NEUTRAL | 70 |
| 50 | `STAN.L` | Standard Chartered PLC | **3/9** | 🔴 SVAG | 58 |
| 15 | `GRNG.ST` | Gränges AB (publ) | **4/9** | ⚪ NEUTRAL | 72 |
| 20 | `AAL.L` | Anglo American plc | **6/9** | ⚪ NEUTRAL | 69 |
| 19 | `CAST.ST` | Castellum AB (publ) | **6/9** | ⚪ NEUTRAL | 70 |
| 7 | `DIOS.ST` | Diös Fastigheter AB (p | **7/9** | 🟢 STARK | 78 |
| 57 | `LLOY.L` | Lloyds Banking Group p | **3/9** | 🔴 SVAG | 55 |

_Universum: 28 STARK · 75 NEUTRAL · 17 SVAG_

## ⚖️ Risk Parity (Positionsstorlek)

_Hur du bör fördela 100 000 kr om du köper Topp 10 (baserat på volatilitet)._

| Ticker | Volatilitet (Årlig) | Föreslagen Vikt | Belopp (vid 100k) |
|--------|---------------------|-----------------|-------------------|
| `INVE-A.ST` | 19.1% 🟢 | **14.4%** | 14,422 kr |
| `INVE-B.ST` | 19.4% 🟢 | **14.2%** | 14,232 kr |
| `INDU-C.ST` | 21.9% 🟢 | **12.6%** | 12,584 kr |
| `INDU-A.ST` | 22.2% 🟢 | **12.4%** | 12,411 kr |
| `PRU.L` | 26.8% 🟡 | **10.3%** | 10,283 kr |
| `RIO.L` | 28.7% 🟡 | **9.6%** | 9,612 kr |
| `BP.L` | 33.6% 🟡 | **8.2%** | 8,196 kr |
| `STAN.L` | 33.7% 🟡 | **8.2%** | 8,179 kr |
| `ANTO.L` | 54.3% 🔴 | **5.1%** | 5,079 kr |
| `INSTAL.ST` | 55.1% 🔴 | **5.0%** | 5,001 kr |


## 📈 Sektormomtentum

_Sektorer i nedtrend drar ned scores för aktier i dem._

| Sektor | ETF | Signal | 1m | 3m | MA50 | MA200 |
|--------|-----|--------|----|----|------|-------|
| Technology | `QQQ` | 🟢🟢 STARK UPPTREND | +15.5% | +16.8% | ✅ | ✅ |
| Consumer Cyclical | `XLY` | 🟢 UPPTREND | +4.8% | +1.1% | ✅ | ✅ |
| Consumer Defensive | `XLP` | 🟢 UPPTREND | +2.2% | -3.8% | ✅ | ✅ |
| Industrials | `XLI` | 🟢 UPPTREND | +1.3% | +0.9% | ✅ | ✅ |
| Communication Services | `XLC` | 🟢 UPPTREND | +0.7% | -1.4% | ✅ | ✅ |
| Basic Materials | `XLB` | 🟢 UPPTREND | +0.1% | -0.8% | ✅ | ✅ |
| Real Estate | `XLRE` | 🟢 UPPTREND | +3.6% | +4.7% | ✅ | ✅ |
| Financial Services | `XLF` | ⚪ NEUTRAL | -0.9% | -3.9% | ✅ | ❌ |
| Energy | `XLE` | ⚪ NEUTRAL | +0.1% | +7.4% | ❌ | ✅ |
| Utilities | `XLU` | ⚪ NEUTRAL | -2.7% | +2.8% | ❌ | ✅ |
| Healthcare | `XLV` | 🔴🔴 STARK NEDTREND | -3.3% | -7.5% | ❌ | ❌ |

## 🏭 Sektorer – rankat efter styrka

| Sektor | Aktier | Snitt-score | Bästa | Score |
|--------|--------|-------------|-------|-------|
| Basic Materials | 9 | **67** | `ANTO.L` | 83 |
| Energy | 2 | **64** | `BP.L` | 66 |
| Technology | 7 | **61** | `NCAB.ST` | 79 |
| Real Estate | 14 | **60** | `DIOS.ST` | 78 |
| Communication Services | 8 | **60** | `CTM.ST` | 72 |
| Consumer Defensive | 6 | **58** | `BATS.L` | 66 |
| Financial Services | 18 | **56** | `INVE-A.ST` | 84 |
| Industrials | 31 | **54** | `INSTAL.ST` | 80 |
| Consumer Cyclical | 13 | **53** | `CLAS-B.ST` | 74 |
| Healthcare | 11 | **31** | `GSK.L` | 42 |
| Utilities | 1 | **28** | `MINEST.ST` | 28 |

## 🔄 Förändringar sedan förra scanningen

### 🆕 Ny i topp 20
- **`CLAS-B.ST`** Clas Ohlson AB (publ) – Score 74 (från rank 21 → #9)
- **`NCAB.ST`** NCAB Group AB (publ) – Score 79 (från rank 25 → #6)
- **`EMIL-B.ST`** Fastighetsbolaget Emilshus AB (publ) – Score 71 (från rank 41 → #16)
- **`MILDEF.ST`** MilDef Group AB (publ) – Score 73 (från rank 32 → #13)
- **`PNDX-B.ST`** Pandox AB (publ) – Score 73 (från rank 29 → #10)
- **`CTM.ST`** Catena Media plc – Score 72 (från rank 36 → #14)
- **`VOD.L`** Vodafone Group Public Limited Company – Score 71 (från rank 42 → #17)

### 📤 Lämnat topp 20
- **`BP.L`** BP p.l.c. – Nu rank #28, score 66
- **`STAN.L`** Standard Chartered PLC – Nu rank #50, score 58
- **`LLOY.L`** Lloyds Banking Group plc – Nu rank #57, score 55
- **`GLEN.L`** Glencore plc – Nu rank #22, score 68
- **`SSAB-A.ST`** SSAB AB (publ) – Nu rank #25, score 68
- **`SSAB-B.ST`** SSAB AB (publ) – Nu rank #27, score 67
- **`GSK.L`** GSK plc – Nu rank #97, score 42

### 📈 Starkast stigande score
- **`HEXA-B.ST`** Hexagon AB (publ) – Score 65 (+18p sedan sist, rank #32)
- **`NCAB.ST`** NCAB Group AB (publ) – Score 79 (+18p sedan sist, rank #6)
- **`CLAS-B.ST`** Clas Ohlson AB (publ) – Score 74 (+13p sedan sist, rank #9)
- **`CTM.ST`** Catena Media plc – Score 72 (+13p sedan sist, rank #14)
- **`ANTO.L`** Antofagasta plc – Score 83 (+13p sedan sist, rank #2)

### 📉 Starkast fallande score
- **`RAY-B.ST`** RaySearch Laboratories AB (publ) – Score 27 (-20p sedan sist)
- **`GSK.L`** GSK plc – Score 42 (-20p sedan sist)
- **`AZN.L`** AstraZeneca PLC – Score 41 (-20p sedan sist)
- **`XVIVO.ST`** Xvivo Perfusion AB (publ) – Score 34 (-20p sedan sist)
- **`GETI-B.ST`** Getinge AB (publ) – Score 31 (-20p sedan sist)


## 📅 Earnings-kalender

### 🔔 Topp-aktier som rapporterar inom 14 dagar

_Var försiktig med köp precis innan rapport (gap-risk)_

| Datum | Dagar kvar | Rank | Ticker | Bolag | Score |
|-------|-----------|------|--------|-------|-------|
| 2026-05-12 | **1** | #? | `VOD.L` | Vodafone Group Public Limited  | 71 |
| 2026-05-12 | **1** | #? | `CTM.ST` | Catena Media plc | 72 |
| 2026-05-20 | **9** | #? | `EXPN.L` | Experian plc | 65 |
| 2026-05-21 | **10** | #? | `BT-A.L` | BT Group plc | 64 |

## 🏭 Sektoranalys & Bästa kandidater

_Vilka sektorer har störst potential just nu? Rankat efter sektorns genomsnittliga score._

| Rank | Sektor | Snitt-score | Antal | Bästa Ticker | Max-score |
|------|--------|-------------|-------|--------------|-----------|
| 1 | **Basic Materials** | 67.0 | 9 | `ANTO.L` | 82.8 |
| 2 | **Energy** | 63.6 | 2 | `BP.L` | 66.3 |
| 3 | **Technology** | 61.4 | 7 | `NCAB.ST` | 78.8 |
| 4 | **Real Estate** | 60.1 | 14 | `DIOS.ST` | 77.7 |
| 5 | **Communication Services** | 59.5 | 8 | `CTM.ST` | 72.1 |
| 6 | **Consumer Defensive** | 57.6 | 6 | `BATS.L` | 65.7 |
| 7 | **Financial Services** | 56.5 | 18 | `INVE-A.ST` | 83.7 |
| 8 | **Industrials** | 53.9 | 31 | `INSTAL.ST` | 79.6 |
| 9 | **Consumer Cyclical** | 52.6 | 13 | `CLAS-B.ST` | 74.4 |
| 10 | **Healthcare** | 30.8 | 11 | `GSK.L` | 42.2 |
| 11 | **Utilities** | 28.4 | 1 | `MINEST.ST` | 28.4 |

---

### 📍 1-5 i Basic Materials
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `ANTO.L` | Antofagasta plc | 82.8 | OK | HÖG | UPPTREND |
| `RIO.L` | Rio Tinto Group | 69.8 | VÄNTA | HÖG | UPPTREND |
| `GRNG.ST` | Gränges AB (publ) | 71.8 | VÄNTA | HÖG | UPPTREND |
| `AAL.L` | Anglo American plc | 69.4 | OK | LÅG | UPPTREND |
| `GLEN.L` | Glencore plc | 68.3 | VÄNTA | MEDEL | UPPTREND |


### 📍 1-5 i Energy
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `BP.L` | BP p.l.c. | 66.3 | OK | MEDEL | VARNING |
| `SHEL.L` | Shell plc | 60.8 | VÄNTA | HÖG | VARNING |


### 📍 1-5 i Technology
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `ENEA.ST` | Enea AB (publ) | 73.0 | VÄNTA | LÅG | UPPTREND |
| `NCAB.ST` | NCAB Group AB (publ) | 78.8 | VÄNTA | MEDEL | UPPTREND |
| `ERIC-B.ST` | Telefonaktiebolaget  | 62.4 | VÄNTA | LÅG | UPPTREND |
| `HEXA-B.ST` | Hexagon AB (publ) | 65.2 | EJ AKTUELL | HÖG | NEDTREND |
| `ANOD-B.ST` | Addnode Group AB (pu | 58.1 | EJ AKTUELL | LÅG | NEDTREND |


### 📍 1-5 i Real Estate
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `CAST.ST` | Castellum AB (publ) | 69.6 | OK | MEDEL | UPPTREND |
| `DIOS.ST` | Diös Fastigheter AB  | 77.7 | STARK | HÖG | UPPTREND |
| `EMIL-B.ST` | Fastighetsbolaget Em | 70.8 | OK | LÅG | UPPTREND |
| `PLAZ-B.ST` | Platzer Fastigheter  | 64.1 | VÄNTA | MEDEL | UPPTREND |
| `PNDX-B.ST` | Pandox AB (publ) | 73.4 | EJ AKTUELL | MEDEL | NEDTREND |


### 📍 1-5 i Communication Services
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `TEL2-B.ST` | Tele2 AB (publ) | 65.1 | OK | HÖG | VARNING |
| `BT-A.L` | BT Group plc | 64.3 | VÄNTA | MEDEL | UPPTREND |
| `CTM.ST` | Catena Media plc | 72.1 | OK | LÅG | UPPTREND |
| `TELIA.ST` | Telia Company AB (pu | 64.3 | VÄNTA | LÅG | UPPTREND |
| `VOD.L` | Vodafone Group Publi | 70.7 | OK | MEDEL | UPPTREND |


### 📍 1-5 i Consumer Defensive
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `TSCO.L` | Tesco PLC | 64.0 | VÄNTA | HÖG | VARNING |
| `BATS.L` | British American Tob | 65.7 | OK | HÖG | UPPTREND |
| `DGE.L` | Diageo plc | 56.6 | EJ AKTUELL | MEDEL | NEDTREND |
| `IMB.L` | Imperial Brands PLC | 56.5 | EJ AKTUELL | MEDEL | NEDTREND |
| `AXFO.ST` | Axfood AB (publ) | 51.7 | EJ AKTUELL | LÅG | NEDTREND |


### 📍 1-5 i Financial Services
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `INVE-A.ST` | Investor AB (publ) | 83.7 | OK | HÖG | UPPTREND |
| `INDU-C.ST` | AB Industrivärden (p | 82.4 | STARK | HÖG | UPPTREND |
| `INDU-A.ST` | AB Industrivärden (p | 81.1 | OK | HÖG | UPPTREND |
| `INVE-B.ST` | Investor AB (publ) | 73.3 | OK | HÖG | UPPTREND |
| `PRU.L` | Prudential plc | 74.5 | OK | HÖG | UPPTREND |


### 📍 1-5 i Industrials
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `INSTAL.ST` | Instalco AB (publ) | 79.6 | OK | MEDEL | UPPTREND |
| `MILDEF.ST` | MilDef Group AB (pub | 72.8 | OK | LÅG | UPPTREND |
| `EXPN.L` | Experian plc | 65.5 | EJ AKTUELL | MEDEL | NEDTREND |
| `ABB.ST` | ABB Ltd | 63.3 | VÄNTA | HÖG | UPPTREND |
| `AQ.ST` | AQ Group AB (publ) | 60.7 | VÄNTA | MEDEL | UPPTREND |


### 📍 1-5 i Consumer Cyclical
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `CLAS-B.ST` | Clas Ohlson AB (publ | 74.4 | STARK | MEDEL | UPPTREND |
| `BILI-A.ST` | Bilia AB (publ) | 54.9 | EJ AKTUELL | MEDEL | UPPTREND |
| `SKIS-B.ST` | SkiStar AB (publ) | 68.1 | EJ AKTUELL | LÅG | NEDTREND |
| `MIPS.ST` | Mips AB (publ) | 64.6 | EJ AKTUELL | LÅG | NEDTREND |
| `EVO.ST` | Evolution AB (publ) | 55.1 | EJ AKTUELL | MEDEL | NEDTREND |


### 📍 1-5 i Healthcare
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `GSK.L` | GSK plc | 42.2 | EJ AKTUELL | MEDEL | VARNING |
| `AZN.L` | AstraZeneca PLC | 40.9 | EJ AKTUELL | MEDEL | VARNING |
| `XVIVO.ST` | Xvivo Perfusion AB ( | 34.3 | EJ AKTUELL | LÅG | UPPTREND |
| `ARJO-B.ST` | Arjo AB (publ) | 30.4 | EJ AKTUELL | LÅG | NEDTREND |
| `GETI-B.ST` | Getinge AB (publ) | 31.2 | EJ AKTUELL | MEDEL | NEDTREND |


### 📍 1-5 i Utilities
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `MINEST.ST` | Minesto AB (publ) | 28.4 | EJ AKTUELL | LÅG | NEDTREND |




## 🤖 Klistra in i Claude Pro
```
Här är min veckovisa scan. Sök senaste 30 dagars nyheter för topp 20
och mina innehav. Filtrera bort röda flaggor.

Ge mig:
1. Topp 10 köpkandidater med motivering
2. Bekräfta/överrid rekommendationerna för mina innehav
3. Varningssignaler jag missat
4. Är jag för exponerad mot en sektor?
5. Vad säger makrobilden just nu?
```

---
*⚠ Inte finansiell rådgivning.*