# 📊 Veckovis Aktiescan
**Datum:** 2026-05-11 23:20  
**Scannade:** 120 aktier
**Vikter:** Value 22% · Quality 18% · Momentum 18% · Growth 13% · Risk 9% · Sentiment 10%
**Signaler:** 69 upptrend · 19 HÖG konfidens · 1 STARK entry

---


## 🐂 Marknadsregim: **TJUR**

_Konfidens: 67%_  
_Per: 2026-05-11 19:59_

| Indikator | Värde |
|-----------|-------|
| SPY vs MA200 | +10.3% |
| VIX | 18.1 |
| SPY 3-mån | +7.2% |

**Anmärkningar:**
- SPY +10.3% över MA200, VIX 18.1

✅ **Tjurmarknad:** Standardvikter används. Momentum-faktorn har lätt förhöjd vikt.

## ⚖️ Risk Parity (Positionsstorlek)

_Hur du bör fördela 100 000 kr om du köper Topp 10 (baserat på volatilitet)._

| Ticker | Volatilitet (Årlig) | Föreslagen Vikt | Belopp (vid 100k) |
|--------|---------------------|-----------------|-------------------|
| `INVE-A.ST` | 19.1% 🟢 | **14.4%** | 14,419 kr |
| `INVE-B.ST` | 19.4% 🟢 | **14.2%** | 14,233 kr |
| `INDU-C.ST` | 21.9% 🟢 | **12.6%** | 12,581 kr |
| `INDU-A.ST` | 22.2% 🟢 | **12.4%** | 12,409 kr |
| `PRU.L` | 26.8% 🟡 | **10.3%** | 10,292 kr |
| `RIO.L` | 28.8% 🟡 | **9.6%** | 9,587 kr |
| `STAN.L` | 33.6% 🟡 | **8.2%** | 8,216 kr |
| `BP.L` | 33.7% 🟡 | **8.2%** | 8,181 kr |
| `ANTO.L` | 54.3% 🔴 | **5.1%** | 5,078 kr |
| `INSTAL.ST` | 55.1% 🔴 | **5.0%** | 5,005 kr |


## 🏭 Sektorer – rankat efter styrka

| Sektor | Aktier | Snitt-score | Bästa | Score |
|--------|--------|-------------|-------|-------|
| Energy | 2 | **64** | `BP.L` | 66 |
| Basic Materials | 9 | **61** | `ANTO.L` | 70 |
| Financial Services | 18 | **58** | `INVE-A.ST` | 76 |
| Communication Services | 8 | **54** | `TEL2-B.ST` | 60 |
| Consumer Defensive | 6 | **53** | `BATS.L` | 61 |
| Real Estate | 14 | **52** | `DIOS.ST` | 65 |
| Technology | 7 | **50** | `ENEA.ST` | 63 |
| Healthcare | 11 | **50** | `GSK.L` | 62 |
| Industrials | 31 | **47** | `INSTAL.ST` | 67 |
| Consumer Cyclical | 13 | **47** | `CLAS-B.ST` | 61 |
| Utilities | 1 | **36** | `MINEST.ST` | 36 |

## 🔄 Förändringar sedan förra scanningen


## 📅 Earnings-kalender

### 🔔 Topp-aktier som rapporterar inom 14 dagar

_Var försiktig med köp precis innan rapport (gap-risk)_

| Datum | Dagar kvar | Rank | Ticker | Bolag | Score |
|-------|-----------|------|--------|-------|-------|
| 2026-05-12 | **1** | #? | `CTM.ST` | Catena Media plc | 59 |
| 2026-05-12 | **1** | #? | `VOD.L` | Vodafone Group Public Limited  | 58 |
| 2026-05-20 | **9** | #? | `EXPN.L` | Experian plc | 60 |
| 2026-05-21 | **10** | #? | `BT-A.L` | BT Group plc | 59 |

## 🏭 Sektoranalys & Bästa kandidater

_Vilka sektorer har störst potential just nu? Rankat efter sektorns genomsnittliga score._

| Rank | Sektor | Snitt-score | Antal | Bästa Ticker | Max-score |
|------|--------|-------------|-------|--------------|-----------|
| 1 | **Energy** | 63.6 | 2 | `BP.L` | 66.3 |
| 2 | **Basic Materials** | 61.2 | 9 | `ANTO.L` | 69.8 |
| 3 | **Financial Services** | 58.3 | 18 | `INVE-A.ST` | 75.7 |
| 4 | **Communication Services** | 53.5 | 8 | `TEL2-B.ST` | 60.1 |
| 5 | **Consumer Defensive** | 52.6 | 6 | `BATS.L` | 60.7 |
| 6 | **Real Estate** | 52.2 | 14 | `DIOS.ST` | 64.7 |
| 7 | **Technology** | 50.2 | 7 | `ENEA.ST` | 63.0 |
| 8 | **Healthcare** | 50.1 | 11 | `GSK.L` | 62.2 |
| 9 | **Industrials** | 47.4 | 31 | `INSTAL.ST` | 66.6 |
| 10 | **Consumer Cyclical** | 46.9 | 13 | `CLAS-B.ST` | 61.4 |
| 11 | **Utilities** | 36.4 | 1 | `MINEST.ST` | 36.4 |

---

### 📍 1-5 i Energy
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `BP.L` | BP p.l.c. | 66.3 | OK | MEDEL | VARNING |
| `SHEL.L` | Shell plc | 60.8 | VÄNTA | HÖG | VARNING |


### 📍 1-5 i Basic Materials
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `ANTO.L` | Antofagasta plc | 69.8 | OK | HÖG | UPPTREND |
| `RIO.L` | Rio Tinto Group | 64.8 | VÄNTA | HÖG | UPPTREND |
| `GRNG.ST` | Gränges AB (publ) | 66.8 | VÄNTA | HÖG | UPPTREND |
| `AAL.L` | Anglo American plc | 64.4 | VÄNTA | LÅG | UPPTREND |
| `GLEN.L` | Glencore plc | 63.3 | VÄNTA | MEDEL | UPPTREND |


### 📍 1-5 i Financial Services
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `INVE-A.ST` | Investor AB (publ) | 75.7 | OK | HÖG | UPPTREND |
| `INDU-C.ST` | AB Industrivärden (p | 74.4 | STARK | HÖG | UPPTREND |
| `INDU-A.ST` | AB Industrivärden (p | 73.1 | OK | HÖG | UPPTREND |
| `INVE-B.ST` | Investor AB (publ) | 73.3 | OK | HÖG | UPPTREND |
| `PRU.L` | Prudential plc | 66.5 | OK | HÖG | UPPTREND |


### 📍 1-5 i Communication Services
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `TEL2-B.ST` | Tele2 AB (publ) | 60.1 | VÄNTA | HÖG | VARNING |
| `BT-A.L` | BT Group plc | 59.3 | VÄNTA | MEDEL | UPPTREND |
| `CTM.ST` | Catena Media plc | 59.1 | VÄNTA | LÅG | UPPTREND |
| `TELIA.ST` | Telia Company AB (pu | 59.3 | VÄNTA | LÅG | UPPTREND |
| `VOD.L` | Vodafone Group Publi | 57.7 | VÄNTA | MEDEL | UPPTREND |


### 📍 1-5 i Consumer Defensive
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `TSCO.L` | Tesco PLC | 59.0 | VÄNTA | HÖG | VARNING |
| `BATS.L` | British American Tob | 60.7 | VÄNTA | HÖG | UPPTREND |
| `DGE.L` | Diageo plc | 51.6 | EJ AKTUELL | MEDEL | NEDTREND |
| `IMB.L` | Imperial Brands PLC | 51.5 | EJ AKTUELL | MEDEL | NEDTREND |
| `AXFO.ST` | Axfood AB (publ) | 46.7 | EJ AKTUELL | LÅG | NEDTREND |


### 📍 1-5 i Real Estate
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `CAST.ST` | Castellum AB (publ) | 64.6 | VÄNTA | MEDEL | UPPTREND |
| `DIOS.ST` | Diös Fastigheter AB  | 64.7 | VÄNTA | HÖG | UPPTREND |
| `EMIL-B.ST` | Fastighetsbolaget Em | 57.8 | VÄNTA | LÅG | UPPTREND |
| `PLAZ-B.ST` | Platzer Fastigheter  | 59.1 | VÄNTA | MEDEL | UPPTREND |
| `PNDX-B.ST` | Pandox AB (publ) | 60.4 | EJ AKTUELL | MEDEL | NEDTREND |


### 📍 1-5 i Technology
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `ENEA.ST` | Enea AB (publ) | 63.0 | VÄNTA | LÅG | UPPTREND |
| `NCAB.ST` | NCAB Group AB (publ) | 60.8 | VÄNTA | MEDEL | UPPTREND |
| `ERIC-B.ST` | Telefonaktiebolaget  | 52.4 | EJ AKTUELL | LÅG | UPPTREND |
| `HEXA-B.ST` | Hexagon AB (publ) | 47.2 | EJ AKTUELL | HÖG | NEDTREND |
| `ANOD-B.ST` | Addnode Group AB (pu | 48.1 | EJ AKTUELL | LÅG | NEDTREND |


### 📍 1-5 i Healthcare
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `GSK.L` | GSK plc | 62.2 | VÄNTA | MEDEL | VARNING |
| `AZN.L` | AstraZeneca PLC | 60.9 | VÄNTA | MEDEL | VARNING |
| `XVIVO.ST` | Xvivo Perfusion AB ( | 54.3 | EJ AKTUELL | LÅG | UPPTREND |
| `ARJO-B.ST` | Arjo AB (publ) | 50.4 | EJ AKTUELL | LÅG | NEDTREND |
| `GETI-B.ST` | Getinge AB (publ) | 51.2 | EJ AKTUELL | MEDEL | NEDTREND |


### 📍 1-5 i Industrials
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `INSTAL.ST` | Instalco AB (publ) | 66.6 | OK | MEDEL | UPPTREND |
| `MILDEF.ST` | MilDef Group AB (pub | 59.8 | VÄNTA | LÅG | UPPTREND |
| `EXPN.L` | Experian plc | 60.5 | EJ AKTUELL | MEDEL | NEDTREND |
| `ABB.ST` | ABB Ltd | 58.3 | VÄNTA | HÖG | UPPTREND |
| `AQ.ST` | AQ Group AB (publ) | 55.7 | VÄNTA | MEDEL | UPPTREND |


### 📍 1-5 i Consumer Cyclical
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `CLAS-B.ST` | Clas Ohlson AB (publ | 61.4 | VÄNTA | MEDEL | UPPTREND |
| `BILI-A.ST` | Bilia AB (publ) | 57.9 | VÄNTA | MEDEL | UPPTREND |
| `SKIS-B.ST` | SkiStar AB (publ) | 55.1 | EJ AKTUELL | LÅG | NEDTREND |
| `MIPS.ST` | Mips AB (publ) | 51.6 | EJ AKTUELL | LÅG | NEDTREND |
| `EVO.ST` | Evolution AB (publ) | 50.1 | EJ AKTUELL | MEDEL | NEDTREND |


### 📍 1-5 i Utilities
| Ticker | Bolag | Score | Entry | Konf | Trend |
|--------|-------|-------|-------|------|-------|
| `MINEST.ST` | Minesto AB (publ) | 36.4 | EJ AKTUELL | LÅG | NEDTREND |



## 🧹 Systemunderhåll (Självläkning)

_Systemet rensar automatiskt bort aktier som saknar data efter 3 misslyckade försök._

### ❌ Raderade från universumet (Blacklist)
| Ticker | AI Diagnos / Orsak |
|--------|--------------------|
| `ANSS` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `K` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `PXD` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `HES` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `X` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `PARA` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `TRELLEBORG-B.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `ELEK-B.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `LUNE.ST` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `BYGGFA.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `IAR-B.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `PROAC-B.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `HEXP-B.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `INVISIO.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `BIOT.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `VITROLIFE.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `STENPRO-A.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `ARISE.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `PARADOX.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `RESURS.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `FNOX.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `VITEC.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `FORM.ST` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `STRAX.ST` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `ONCOPEPTIDES.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `TBPL.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `SECURE.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `PEXIP.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `CONCEN.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `MENTICE.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `CALLI.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `MEDCAP.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `RECI-B.ST` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `K-FAST-B.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `OREX.ST` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `DPW.DE` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `ML.PA` | Okänd brist i datakvalitet |
| `STM.PA` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `RICN.SW` | Yahoo Finance hittar ingen data (kontrollera ticker-suffix) |
| `DSM.AS` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `URW.AS` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |
| `NZYM-B.CO` | Fundamentaldata saknas hos Yahoo (vanligt för små/europeiska bolag) |



## 🤖 Klistra in i Claude Pro
```
Här är min veckovisa scan. Sök senaste 30 dagars nyheter för topp 20
och mina innehav. Filtrera bort röda flaggor.

Ge mig:
1. Topp 10 köpkandidater med motivering
2. Bekräfta/överrid rekommendationerna för mina innehav
3. Varningssignaler jag missat
4. Är jag för exponerad mot en sektor?
5. Vad säger makrobilden just nu?
```

---
*⚠ Inte finansiell rådgivning.*